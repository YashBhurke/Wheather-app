async function getWeather() {
  const apiKey = "f2113a834f864e7abc533805253006"; 
  const city = document.getElementById("cityInput").value; 
  const url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}`;

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.error) {
      document.getElementById("weatherResult").innerText = "City not found!";
    } else {
      document.getElementById("weatherResult").innerHTML = `
        <p><strong>${data.location.name}, ${data.location.country}</strong></p>
        <p>${data.current.condition.text}</p>
        <img src="https:${data.current.condition.icon}" alt="Weather icon">
        <p> ${data.current.temp_c} °C</p>
      `;
    }
  } catch (error) {
    document.getElementById("weatherResult").innerText = "Error fetching weather.";
  }
}

